<?php
// menggunakan  associative array

//menu untuk bagian atas
$menuAtas = [
    "home"=>"home",
    "produk"=>"produk", 
    "pesan"=>"pesan",
    "gesbuk"=>"gesbuk",
];

// menu untuk di bagian bawah 
$menuBawah = [
    "home"=>"home.php",
    "produk"=>"produk.php", 
    "pesan"=>"pesan.php",
    "gesbuk"=>"gesbuk.php",
];
?>