<div style="text-align: center; background-color: black; color: white;">
        Copyright @dono - 2024
    </div>

</body>
</html>